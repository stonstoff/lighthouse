from .senko import Senko
